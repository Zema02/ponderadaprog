exports.home = (req, res) => {
    res.render('home', { titulo: 'Bem-vindo ao meu projeto MVC!' });
  };
  