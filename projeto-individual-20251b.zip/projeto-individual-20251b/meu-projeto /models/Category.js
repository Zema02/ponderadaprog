class Category {
    constructor(id, name) {
      this.id = id;
      this.name = name;
    }
  }
  
  module.exports = Category;
  